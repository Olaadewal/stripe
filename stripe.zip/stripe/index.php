<!DOCTYPE html>
<html>
<head>
    <title>Payment Form</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.8.3/font/bootstrap-icons.min.css">
    <!-- End Bootstrap CSS -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <style>
        /* Style the form container */
        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh; /* Use min-height for responsiveness */
            background-image: url('pay.jpg');
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-size: cover; /* Make the background image responsive */
        }

        .container {
            text-align: center;
        }

        #payment-form {
            background: rgba(255, 255, 255, 0.8);
            padding: 20px;
            border-radius: 20px; /* Improved border-radius */
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            width: 100%;
            margin: 0 auto; /* Center the form horizontally */
        }

        /* Center form row horizontally */
        .center-form-row {
            display: flex;
            justify-content: center;
            align-items: flex-start;
            margin-bottom: 15px;
        }

        .form-field {
            flex: 1;
            margin-bottom: 10px;
            margin-right: 10px;
        }

        /* Style the submit button row */
        .submit-row {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }

        /* Style form errors */
        #card-errors {
            color: #ff0000;
            margin-top: 10px;
        }

        /* Add a simple animation */
        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        #payment-form {
            animation: fadeIn 0.5s;
        }

        /* Style form inputs */
        input[type="text"],
        input[type="number"] {  
            width: 100%;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px; /* Improved border-radius */
        }

        #submit {
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 10px; /* Adjust border-radius */
            padding: 15px 30px; /* Adjust padding */
            cursor: pointer;
            transition: background-color 0.3s ease;
            width: 98.2%; /* Full width on small screens */
            margin: 0 auto; /* Center the submit button */
        }

        #submit:hover {
            background-color: #0056b3; /* Change color on hover */
        }

        .logo img {
            max-width: 120px; /* Adjust the max-width as needed */
            display: block;
            margin: 0 auto; /* Center the image horizontally */
        }
    </style>
</head>

<body>
    <div class="container">
        <form id="payment-form" method="post">
            <div class="logo">
                <img src="image.png" alt="Your Logo">
            </div>
            <h1><b style="color: grey;">Payment For Your Girl</b></h1>
            <div class="center-form-row"> <!-- Center this row horizontally -->
                <div class="form-field">
                    <input type="number" id="amount" name="amount" placeholder="Amount" required>
                </div>
            </div>

            <script src="https://checkout.stripe.com/checkout.js" class="stripe-button"
                data-key="pk_test_51Nv4x3DluAG2hlhfjn6NPHpta63VtLlY8f1wwVvc51mhglvB9NEqkNLG5l8leiD9BF5zTbyKGkS6444KAn57Ms2V00R64rVUbZ "
                data-amount="0"  
                data-description="Payment"
                data-image="https://stripe.com/img/documentation/checkout/marketplace.png"
                data-locale="auto">
            </script>

            <script>
                document.querySelector('#amount').addEventListener('input', function () {
                    var amount = parseFloat(this.value);
                    if (!isNaN(amount)) {
                        // Convert input value to cents and update data-amount
                        document.querySelector('.stripe-button').setAttribute('data-amount', amount * 100);
                    }
                });
            </script>
        </form>
    </div>
</body>
</html>
